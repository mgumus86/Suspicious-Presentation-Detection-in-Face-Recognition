This project requires Python 3.8 to run the project notebooks. 

Specific python packages are also required and can be installed using the below command:
```
pip install -r requirements.txt
```